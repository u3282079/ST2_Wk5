import timeit

variable = 25

# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Example usage:
result = fibonacci(variable)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The {variable}th Fibonacci number is {result}")

# Timer Code
fibonacci_time = timeit.timeit(lambda: fibonacci(variable), number=1000)
print(f"Fibonacci Recursive Execution Time: {fibonacci_time:.6f} seconds")

# spacer
print("")

def fibonnaci_iterative(n):
    a = 0
    b = 1

    if n == 1:
        return b
    else:
        for i in range(1, n):
            c = a + b
            a = b
            b = c
        return b



if __name__ == '__main__':
    n = variable
    print(f"The {variable}th Fibonacci number is {fibonnaci_iterative(variable)}")

# Timer Code
fibonacci_iterative_time = timeit.timeit(lambda: fibonnaci_iterative(variable), number=1000)
print(f"Fibonacci Iterative Execution Time: {fibonacci_iterative_time:.6f} seconds")

