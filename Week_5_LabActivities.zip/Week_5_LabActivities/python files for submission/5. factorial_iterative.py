import timeit

variable = 30

def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

n = variable
print(f"The factorial of {n} using Recursion is {factorial(n)}")

# Timer Code
factorial_recursive_time = timeit.timeit(lambda: factorial(variable), number=1000)
print(f"Factorial Recursive Execution Time: {factorial_recursive_time:.6f} seconds")

# spacer
print("")

def factorial_iterative(n):

    if n >= 0:
        f = 1
        for i in range(1, n+1):
            f *= i
        return f

# Example usage:
n = variable
print(f"The factorial of {n} using an Iterative Loop is {factorial_iterative(n)}")

# Timer Code
factorial_iterative = timeit.timeit(lambda: factorial_iterative(variable), number=1000)
print(f"Factorial Iterative Loop Execution Time: {factorial_iterative:.6f} seconds")