moves = 0

#moves+=1
# moves += 1

def main():
    global moves
    moves = 0

    n = eval(input("Enter number of disks: "))
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print("")
    print("Number of moves:", moves)
# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global moves

    if n == 1: # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
        moves+=1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        moves+=1
        moveDisks(n - 1, auxTower, toTower, fromTower)



main() # Call the main function