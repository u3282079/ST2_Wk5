from tkinter import * # Import tkinter
import math

class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Koch Snowflake") # Set a title
        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width = self.width, height = self.height)
        self.canvas.pack()
        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()
        Label(frame1,
        text = "Enter an order: ").pack(side = LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable = self.order, justify = RIGHT).pack(side = LEFT)
        Button(frame1, text = "Display Koch Snowflake",
            command = self.display).pack(side = LEFT)

        window.mainloop() # Create an event loop

    def display(self):
        self.canvas.delete("line")

        # making a triangle
        p1 = [self.width / 2, 20]
        p2 = [20, self.height - 20]
        p3 = [self.width - 20, self.height - 20]

        order = int(self.order.get())

        # 3 Koch Sides
        self.koch(order, p1, p2)
        self.koch(order, p2, p3)
        self.koch(order, p3, p1)

    def koch(self, order, p1, p2):
        # draw a koch fractal line between p1 and p2
        if order == 0:
            self.drawLine(p1, p2)
        else:
            x1, y1 =p1
            x2, y2 =p2

            dx = (x2 - x1) / 3
            dy = (y2 - y1) / 3

            pA = [x1 + dx, y1 + dy]
            pB = [x1 + 2*dx, y1 + 2*dy]

            angle = math.radians(60)
            px = pA[0] + (dx * math.cos(angle) - dy * math.sin(angle))
            py = pA[1] + (dx * math.sin(angle) + dy * math.cos(angle))
            pPeak=[px, py]

            self.koch(order - 1, p1, pA)
            self.koch(order - 1, pA, pPeak)
            self.koch(order - 1, pPeak, pB)
            self.koch(order - 1, pB, p2)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags = "line"
        )

    def displayTriangles(self, order, p1, p2, p3):
        if order == 0: # Base condition
            # Draw a triangle to connect three points
            self.drawLine(p1, p2)
            self.drawLine(p2, p3)
            self.drawLine(p3, p1)
        else:
            # Get the midpoint of each triangle's edge
            p12 = self.midpoint(p1, p2)
            p23 = self.midpoint(p2, p3)
            p31 = self.midpoint(p3, p1)
            # Recursively display three triangles
            self.displayTriangles(order - 1, p1, p12, p31)
            self.displayTriangles(order - 1, p12, p2, p23)
            self.displayTriangles(order - 1, p31, p23, p3)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags = "line")
    # Return the midpoint between two points
    def midpoint(self, p1, p2):
        p = 2 * [0]
        p[0] = (p1[0] + p2[0]) / 2
        p[1] = (p1[1] + p2[1]) / 2
        return p
KochSnowflake() # Create GUI