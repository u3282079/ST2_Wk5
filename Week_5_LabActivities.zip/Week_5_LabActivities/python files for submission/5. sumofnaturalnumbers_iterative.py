import timeit


# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Example usage:
result = sum_of_natural_numbers(500)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 500 natural numbers, using recursion, is {result}")

# Timer Code
simple_recursive_time = timeit.timeit(lambda: sum_of_natural_numbers(5), number=1000)
print(f"Simple Sum Recursive Execution Time: {simple_recursive_time:.6f} seconds")

# Spacer
print("")

def sum_of_natural_numbers_iterative(n):
    sum = 0
    i = 1
    while i <= n:
        sum = sum + i
        i = i + 1
    return sum

if __name__ == '__main__':
    n = 500
    print(f"The sum of the first 500 natural numbers, using an iteration loop, is {(sum_of_natural_numbers_iterative(n))}")

# Timer Code
simple_iterative_time = timeit.timeit(lambda: sum_of_natural_numbers_iterative(5), number=1000)
print(f"Simple Sum Iterative Execution Time: {simple_iterative_time:.6f} seconds")